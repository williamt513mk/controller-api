#ifndef _NPY_PYCOMPAT_H_
#define _NPY_PYCOMPAT_H_

#include "numpy/npy_3kcompat.h"

#endif /* _NPY_COMPAT_H_ */
